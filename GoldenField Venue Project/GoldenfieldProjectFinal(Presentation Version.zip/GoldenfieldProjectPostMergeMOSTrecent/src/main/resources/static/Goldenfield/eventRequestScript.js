//Elements by Id
//Fieldset 1
const form = document.getElementById('form');
const eventType = document.getElementById('eventType');
const performers = document.getElementById('performers');
const startDate = document.getElementById('startDate');
const startTime = document.getElementById('startTime');
const attendance = document.getElementById('attendance');
const ages = document.getElementById('ages');
const otherLabel = document.getElementById('otherLabel');
const budget = document.getElementById('budget');
const eventDetails = document.getElementById('eventDetails');

//Fieldset 2
const company = document.getElementById('company');
const firstName = document.getElementById('firstName');
const lastName = document.getElementById('lastName');
const phone = document.getElementById('phone');
const phoneMessage = document.getElementById('phoneMessage');
const email = document.getElementById('email');
const emailMessage = document.getElementById('emailMessage');
const contactTime = document.getElementById('contactTime');
const links = document.getElementById('links');
const contactNotes = document.getElementById('contactNotes');

phone.addEventListener('input', isValidRequestPhone);
phone.addEventListener('mouseout', displayErrorMsg);
email.addEventListener('mouseout', isValidRequestEmail);
let requestPhoneValid = false;
let requestEmailValid = false;

//Elements by class
const classHidden = document.getElementsByClassName('hidden');

//Display input if user selects "Other"
ages.addEventListener('change', () => {
    if (ages.value === 'other') {
        for (let elm of classHidden) {
            elm.style.display = 'inline';
        }
    }
    else {
        for (let elm of classHidden) {
            elm.style.display = 'none';
        }
    }
});

//Error message for phone input
function displayErrorMsg() {
    if (requestPhoneIsValid) {
        phoneMessage.classList.remove('error');
        phoneMessage.textContent = "";
        phoneMessage.style.display = 'none';
        return;
    }
    else {
        phoneMessage.classList.add('error');
        phoneMessage.style.display = 'block';
        phoneMessage.textContent = "Please enter a valid phone number";
    }
}

//Check if phone number is valid & don't allow data entry other than numbers
function isValidRequestPhone() {
    let digits = this.value.replace(/\D/g, '');
    if (digits.length > 10) digits = digits.slice(0, 10);
    //000-000-0000 placeholder
    let formatted = '';
    if (digits.length > 0) {
        formatted = digits.substring(0, 3);
    }
    if (digits.length >= 4) {
        formatted += '-' + digits.substring(3, 6);
    }
    if (digits.length >= 7) {
        formatted += '-' + digits.substring(6, 10);
    }
    this.value = formatted;
    requestPhoneIsValid = (digits.length === 10);
}

//Make sure email is valid(ex: 'xxxxx@.com')
function isValidRequestEmail() {
    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    const isValid = emailRegex.test(email.value.trim());
    if (email.value.trim() !== "") {
        if (!isValid) {
            emailMessage.classList.add('error');
            emailMessage.style.display = 'block';
            emailMessage.textContent = "Please enter a valid email address";
        } else {
            emailMessage.classList.remove('error');
            emailMessage.style.display = 'none';
            requestEmailIsValid = true;
        }
    }
}

//Block selecting a date that has already occurred in real time
startDate.addEventListener('click', minDate);
function minDate() {
    const today = new Date();
    const mm = String(today.getMonth() + 1).padStart(2,'0');
    const dd = String(today.getDate() + 1).padStart(2,'0');
    const yyyy = today.getFullYear();
    const todayString = `${yyyy}-${mm}-${dd}`;
    startDate.min = todayString;
}

form.addEventListener('submit', function(event) {
    event.preventDefault();

    //Check for invalid phone & email again on submit event
    const elmErrors = document.querySelectorAll('.error');
    //If errors...
    if (elmErrors.length > 0) {
      alert('errors exist');
      //Stop submission/data being sent
      return;
    }

    //Else send data with the values entered in the form
    const eventData = {
        eventType: eventType.value,
        performers: performers.value,
        startDate: startDate.value,
        startTime: startTime.value,
        attendance: attendance.value,
        ages: ages.value,
        otherLabel: otherLabel.value,
        budget: budget.value,
        eventDetails: eventDetails.value,
        company: company.value,
        firstName: firstName.value,
        lastName: lastName.value,
        phone: phone.value,
        email: email.value,
        contactTime: contactTime.value,
        links: links.value,
        contactNotes: contactNotes.value
    }

    //Fetch call for Post Mapping
    fetch('http://localhost:8080/api/eventrequest', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(eventData),
    }).then(response => response.text())
            .then(data => alert(data))
            .catch(error => console.error('Error:', error));

    //Clear each input after submission
    const formInputs = document.querySelectorAll('.formInput');
       formInputs.forEach(input => {
        input.value = "";
    })
});