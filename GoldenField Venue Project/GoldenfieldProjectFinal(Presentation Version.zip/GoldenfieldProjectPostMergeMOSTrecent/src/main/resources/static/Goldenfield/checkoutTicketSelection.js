let ticketSelection = ticketSelect.value;
const listings = document.getElementById('listings');
let currentSection = null;
let cartItems = [];
let currentRow = null;

const listingsDiv = document.createElement('div');
listingsDiv.textContent = 'Click map sections to view ticket availability';
listingsDiv.classList.add('ticket-div');

//Get params sent in calendar to checkout html pg redirection
function getQueryParam(param) {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get(param);
}

//Format time of show to be user-friendly (12 hour) in UI
function format12Hour(timeStr) {
    if (!timeStr || typeof timeStr !== 'string') return '';

    const parts = timeStr.split(':');
    if (parts.length < 2) return '';

    let hours = parseInt(parts[0], 10);
    const minutes = parts[1];
    const ampm = hours >= 12 ? 'PM' : 'AM';

    hours = hours % 12 || 12;
    return `${hours}:${minutes} ${ampm}`;
}

//Formate date of show to be user-friendly in UI
function formatDateWithSuffix(dateStr) {
    try {
        if (!/^\d{4}-\d{2}-\d{2}$/.test(dateStr)) {
            throw new Error("Invalid date format. Expected YYYY-MM-DD.");
        }

        const date = new Date(dateStr);
        if (isNaN(date.getTime())) {
            throw new Error("Invalid date value.");
        }

        const months = [
            "January", "February", "March", "April", "May", "June",
            "July", "August", "September", "October", "November", "December"
        ];

        const day = date.getDate();
        const year = date.getFullYear();
        const monthName = months[date.getMonth()];

        const suffix = (day % 10 === 1 && day !== 11) ? "st" :
                       (day % 10 === 2 && day !== 12) ? "nd" :
                       (day % 10 === 3 && day !== 13) ? "rd" : "th";

        return `${monthName} ${day}${suffix}, ${year}`;
    } catch (err) {
        return `Error: ${err.message}`;
    }
}

//Get the Query param values
window.onload = function() {
    const artistName = getQueryParam('show');
    const showTime = getQueryParam('time');
    const showDate = getQueryParam('date');
    const showId = getQueryParam('id');
    const safeId = showId !== null && !isNaN(showId) ? Number(showId) : null;

    //Get parking info for UI update(passes sold out yet?)
    getEventParking(safeId);

    //Get section/row info for UI(row sold out? entire section sold out?)
    for (let sectionId = 1; sectionId <= 8; sectionId++) {
        getSoldOutSections(sectionId);
    }

    //Use artist name for identifier
    if (artistName) {
        const updateTime = format12Hour(showTime);
        const updateDate = formatDateWithSuffix(showDate);
        displayShowInfo(artistName, updateTime, updateDate);
    } else {
        console.long('unknown artist');
    }
};

//Display show details from param values on checkout page
function displayShowInfo(artistName, showTime, showDate) {
    showPerformers.textContent = artistName;
    showDay.textContent = showDate;
    showHour.textContent = showTime;
}

//Listen for a change in the number of tickets to be purchased. Update UI with this change for the currently clicked section
ticketSelect.addEventListener('change', () => {
   ticketSelection = ticketSelect.value;
   if (currentSection != null) {
    loadSectionRows(currentSection)
   }
})

//Set individual click event listeners for each section- triggers UI update
document.getElementById('section1').addEventListener('click', () => {
    loadSectionRows(1);
    currentSection = 1;
});

document.getElementById('section2').addEventListener('click', () => {
    loadSectionRows(2);
    currentSection = 2;
});

document.getElementById('section8').addEventListener('click', () => {
    loadSectionRows(8);
    currentSection = 8;
});

document.getElementById('section3').addEventListener('click', () => {
    loadSectionRows(3);
    currentSection = 3;
});

document.getElementById('section4').addEventListener('click', () => {
    loadSectionRows(4);
    currentSection = 4;
});

document.getElementById('section5').addEventListener('click', () => {
    loadSectionRows(5);
    currentSection = 5;
});

document.getElementById('section6').addEventListener('click', () => {
    loadSectionRows(6);
    currentSection = 6;
});

document.getElementById('section7').addEventListener('click', () => {
    loadSectionRows(7);
    currentSection = 7;
});

//Get parking info that must be reflected in UI
async function getEventParking(safeId) {
    if (safeId === null) {
        console.warn("Invalid or missing event ID in URL");
        return;
    }

    try {
        const addPassDiv = document.getElementById('addPassDiv');
        const declinePassDiv = document.getElementById('declinePassDiv');
        const parkingStatus = document.getElementById('parkingPara');

        const response = await fetch(`/api/eventparking/${safeId}`);
        if (!response.ok) throw new Error("Failed to fetch event parking data. Event may have been created before 'parkingbyevent' table configuration");

        const data = await response.json();
        if (!data) {
            console.warn("No parking data returned");
            return;
        }

        //Set the status of the parking pass section in the checkout slide
        const checkSoldout = Boolean(data.soldoutEvent);
         if (checkSoldout) {
            parkingStatus.textContent = "SOLD OUT";
            declinePass.checked = true;
            addPassDiv.style.visibility = 'hidden';
            declinePassDiv.style.visibility = 'hidden';
        } else {
            addPassDiv.style.visibility = 'visible';
            declinePassDiv.style.visibility = 'visible';
        }
    } catch (err) {
        console.error(err);
        alert("Failed to fetch event parking data");
    }
}

//Update UI when user clicks on a section
async function loadSectionRows(section) {
    const showId = getQueryParam('id');
    const safeId = showId !== null && !isNaN(showId) ? Number(showId) : null;
    const sectionId = section;

    try {
        const response = await fetch(`/api/sections/${sectionId}/${safeId}`);
        if (!response.ok) throw new Error("Failed to fetch rows");

        const rows = await response.json();
        listings.innerHTML = '';

        if (rows.length === 0) {
            //const soldOutDiv = document.createElement('div');
            //soldOutDiv.textContent = "SOLD OUT";
            //soldOutDiv.className = 'listingsMessage-div';
            //listings.appendChild(soldOutDiv);
            listings.innerHTML = "SOLD OUT";
            return;
            //create div, add class, set text content
        }
        else {
            rows.forEach(r => {
                const rowDiv = document.createElement('div');
                rowDiv.className = 'ticket-div';

                //Use fetched data to update text content of 'tickets' displayed in UI
                const safeRowNumber = String(r.rowsInSection);
                const safeSectionId = String(r.clickedSection);
                const safeTicketsLeft = String(r.ticketsInRow);
                const checkSoldOutRow = Boolean(r.soldOutRow);

                //Don't use sectionid (8) for GA to be displayed
                if (currentSection === 8) {
                rowDiv.textContent = `${ticketSelection} Tickets - Section GA PIT  (${safeTicketsLeft} left!)`;
                }
                //Display sectionid for all other sections
                else {
                rowDiv.innerHTML = `${ticketSelection} Tickets <br>Section ${safeSectionId} Row ${safeRowNumber} (${safeTicketsLeft} left!)<br>`;
                }

                //Append a button to each 'ticket'
                const addToCart = document.createElement('button');
                    addToCart.textContent = 'Add to Cart';
                    addToCart.classList.add('addToCartBtn');

                addToCart.addEventListener('click', () => {
                    //Extra check
                    if (r.ticketsInRow > 0) {
                        openOverlay();
                        currentRow = Number(safeRowNumber);
                    }
                    else {
                        alert(`No tickets left for Row ${safeRowNumber}`);
                    }
                });

                //Display tickets ONLY IF ticket select value is less than/equal to what is available in that row
                if (r.ticketsInRow >= ticketSelection) {
                    rowDiv.appendChild(addToCart);
                    listings.appendChild(rowDiv);
                }
            });
        }
    } catch (err) {
        console.error(err);
        //const errorDiv = document.createElement('div');
        //errorDiv.textContent = 'Error: unable to retrieve ticket availability';
        //errorDiv.classList.add('listingsMessage-div');
        //document.getElementById("listings").appendChild(errorDiv);
        document.getElementById("listings").innerHTML = "Error loading rows.";
    }
}

//Fetch section availability & update UI accordingly
async function getSoldOutSections(sectionId) {
    const showId = getQueryParam('id');
    const safeId = showId !== null && !isNaN(showId) ? Number(showId) : null;

    if (safeId === null) {
        console.error("Invalid or missing event ID");
        return;
    }
    try {
        const response = await fetch(`/api/soldout/sections/${sectionId}/${safeId}`);
        const isSoldOut = await response.json();
        const sectionDiv = document.getElementById(`section${sectionId}`);
        //Change section style if sold out
        if (isSoldOut) {
            sectionDiv.style.backgroundColor = "lightgray";
            sectionDiv.style.cursor = "default";
            sectionDiv.classList.add("soldOutSection");
        }
    } catch (error) {
        console.error("Error fetching sold-out status:", error);
    }
}