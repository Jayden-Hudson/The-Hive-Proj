previousSlideButton.addEventListener('click', prevSlide);

//slide 1
checkoutEmail.addEventListener('mouseout', checkEmailsMatch);
confirmEmail.addEventListener('mouseout', checkEmailsMatch);
checkoutEmail.addEventListener('blur', isValidEmail);
phone.addEventListener('input', isValidPhone);

//slide 1
let emailsMatch = false;
let emailIsValid = false;
let phoneIsValid = false;
let slideOneValid = false;

//slide 2
let cityIsValid = false;
let zipIsValid = false;
let cardIsValid = false;
let cvvIsValid  = false;
let slideTwoValid = false;

//slide 2
city.addEventListener('input', isValidCity);
cardNumber.addEventListener('input', isValidCard);
zip.addEventListener('input', isValidZip);
cvv.addEventListener('input', isValidCvv);

//slide 3
declinePass.addEventListener('change', () => enforceOneChecked(declinePass, addPass));
addPass.addEventListener('change', () => enforceOneChecked(addPass, declinePass));
declineProtection.addEventListener('change', () => enforceOneChecked(declineProtection, addProtection));
addProtection.addEventListener('change', () => enforceOneChecked(addProtection, declineProtection));

let numberOfTickets = 0;
const pricePerTicket = 49.95
const salesTaxRate = 0.0435;
let totalOfAllPrices = 0;
let calcPassPrice =  0;
let calcProtectionPrice = 0;
let calcTicketPrice = 0;
let salesTaxAmount = 0;

declinePass.addEventListener('change', getPassPrice);
addPass.addEventListener('change', getPassPrice);

declineProtection.addEventListener('change', getProtectionPrice);
addProtection.addEventListener('change', getProtectionPrice);

nextSlideButton.addEventListener('click', nextSlide);
const nextButtonOverlay = document.getElementById('nextButtonOverlay');
const backButtonOverlay = document.getElementById('backButtonOverlay');

//Set pass price based on checked checkbox
function getPassPrice() {
    if (declinePass.checked) {
        calcPassPrice = 0;
    } else if (addPass.checked) {
        calcPassPrice = 7.75;
    }
}

//Set protection price based on checked checkbox
function getProtectionPrice() {
    if (declineProtection.checked) {
        calcProtectionPrice = 0;
    } else if (addProtection.checked) {
        calcProtectionPrice = 10.95;
    }
}

//Check for a valid email
function isValidEmail() {
    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    const isValid = emailRegex.test(checkoutEmail.value.trim());

    if (checkoutEmail.value.trim() !== "") {
        if (!isValid) {
        checkoutEmailMessage.textContent = "Invalid email address";
        checkoutEmailMessage.className = "error";
        confirmEmail.style.pointerEvents = 'none';
        } else {
            confirmEmail.style.pointerEvents = 'auto';
            emailIsValid = true;
        }
    }
}

//Check if emails match - also determines if entry is valid
function checkEmailsMatch() {
    if (confirmEmail.value.trim() === "" || checkoutEmail.value.trim() === "") {
        checkoutEmailMessage.textContent = "";
        confirmEmailMessage.textContent = "";
        return;
    }
    if (checkoutEmail.value.trim() === confirmEmail.value.trim()) {
        checkoutEmailMessage.textContent = "";
        confirmEmailMessage.textContent = "";
        checkoutEmailMessage.className = "success";
        confirmEmailMessage.className = "success";  
        emailsMatch = true; 
    } else {
        checkoutEmailMessage.textContent = "Emails do not match";
        confirmEmailMessage.textContent = "Emails do not match";
        checkoutEmailMessage.className = "error";
        confirmEmailMessage.className = "error";
        emailsMatch = false;
    }
}

function isValidPhone() {
        //No letters allowed in input
        let digits = this.value.replace(/\D/g, '');

        //Let only 10 numbers be typed into input
        if (digits.length > 10) digits = digits.slice(0, 10);

        //000-000-0000 placeholder/format
        let formatted = '';
        if (digits.length > 0) {
            formatted = digits.substring(0, 3);
        }
        if (digits.length >= 4) {
            formatted += '-' + digits.substring(3, 6);
        }
        if (digits.length >= 7) {
            formatted += '-' + digits.substring(6, 10);
        }
        this.value = formatted;
        phoneIsValid = (digits.length === 10);
    }

//Control between whats typed and what actualy shows up in city input
city.addEventListener('keydown', function (e) {
    if (e.key === ' ' && this.selectionStart === 0) {
        e.preventDefault();
    }
    const controlKeys = [
            'Backspace', 'Delete', 'ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown',
            'Tab', 'Home', 'End'
        ];
    if (controlKeys.includes(e.key)) {
        return;
    }
    //Only letters, numbers, a space, and a hyphen allowed
    const allowedPattern = /^[a-zA-Z0-9\- ]$/;
    if (!allowedPattern.test(e.key)) {
        e.preventDefault();
    }
});

//Prevent further potential 'wonky' city input entries
function isValidCity() {
    let value = this.value.replace(/[^a-zA-Z0-9 -]/g, '');

    //Starts with: letter or number
    //Spaces & hypens only allowed between words
    const cityRegex = /^[A-Za-z0-9]+(?:[ -][A-Za-z0-9]+)*\s?$/;

    if (value.trim() === "") {
        cityIsValid = false;
    } else if (!cityRegex.test(value.trim())) {
        cityIsValid = false;
    } else {
        cityIsValid = true;
    }
    console.log(cityIsValid);
}

//Prevent poor zip code input
function isValidZip() {
    let digits = this.value.replace(/\D/g, '');

    //Only 5 numbers can be entered
    if (digits.length > 5) {
        digits = digits.slice(0, 5);
    }
    this.value = digits;
    zipIsValid = (digits.length === 5);
}

//Beat the backspace 'bug'
cardNumber.addEventListener('keydown', function (e) {
    if (e.key === 'Backspace') {
        let location = this.selectionStart;
        if (location > 0 && this.value[location - 1] === ' ') {
            e.preventDefault();
            this.setSelectionRange(location - 1, location - 1);
        }
    }
});

//Ensure card number data is valid
function isValidCard() {
    //Don't let anything other than numbers to be entered
    let digits = this.value.replace(/\D/g, '');
    if (digits.length > 16) digits = digits.slice(0, 16);

    //xxxx xxxx xxxx xxxx
    let formatted = '';
    for (let i = 0; i < digits.length; i += 4) {
       if (i > 0) formatted += ' ';
       formatted += digits.substring(i, i + 4);
    }

    this.value = formatted;
    cardIsValid = (digits.length === 16);
}

//Ensure cvv data is valid
function isValidCvv() {
    let digits = this.value.replace(/\D/g, '');

    if (digits.length > 3) {
        digits = digits.slice(0, 3);
    }
    this.value = digits;
    cvvIsValid = (digits.length === 3);
}


//Check data validity: do not let user go to next slide if the current slide is missing data or has bad data
nextButtonOverlay.addEventListener('mouseover', () => {
    // CHECK SLIDE 1
    if (currentSlide == 0) {
        const slide1inputs = document.querySelectorAll('.slide1input');
        let allFilled = true;

        for (const input of slide1inputs) {
            if (input.value.trim() === "") {
                allFilled = false;
                break; 
            }
        }

        //If all is valid, enable next button to be clicked
        if (allFilled && emailsMatch && emailIsValid && phoneIsValid) {
            nextSlideButton.style.pointerEvents = 'auto';
            slideOneValid = true;
        } else {
            alert('* Indicates a required field. All required fields must be filled out before proceeding.');
            slideOneValid = false;
        }
    }

    // CHECK SLIDE 2
     if (currentSlide == 1) {
        let allFilled = true;
        let selectsSelected = true;

        const slide2inputs = document.querySelectorAll('.slide2input');
        const slide2select = document.querySelectorAll('.slide2select');

        for (const select of slide2select) {
            if (select.value === "") {
                selectsSelected = false;
                break; 
            } 
        }

        for (const input of slide2inputs) {
            if (input.value.trim() === "") {
                allFilled = false;
                break; 
            }
        }

        //If vaild, allow next button to be clicked
        if (allFilled && selectsSelected && cityIsValid && zipIsValid && cardIsValid && cvvIsValid) {
            nextSlideButton.style.pointerEvents = 'auto';
            slideTwoValid = true;
        } else {
            alert('Please fill out all required fields.');
            nextSlideButton.style.pointerEvents = 'none';
            slideTwoValid = false;
        }
        totalOrder();
    }
})


//Ensure one checkbox is always checked
function enforceOneChecked(firstBox, secondBox) {
    if (firstBox.checked) {
      //uncheck second box
      secondBox.checked = false;
    } else {
      //check first box
      secondBox.checked = true;
    }
}

//Determine parking pass price
function getPassPrice() {
    if (declinePass.checked) {
        calcPassPrice = 0.00;
    } else if (addPass.checked) {
        calcPassPrice = 7.75;
    }
    totalOrder();
}

//Determine ticket protection price
function getProtectionPrice() {
    if (declineProtection.checked) {
        calcProtectionPrice = 0;
    } else if (addProtection.checked) {
        calcProtectionPrice = 10.95
    }
    totalOrder();
}

//Total order
function totalOrder() {
    numberOfTickets = ticketSelect.value;
    ticketPrice.textContent = "$" + pricePerTicket + " x " + numberOfTickets;

    salesTaxAmount = (pricePerTicket * numberOfTickets) * salesTaxRate;

    //Round value first
    salesTaxAmount = Math.round(salesTaxAmount * 100) / 100;
    salesTax.textContent = "$" + salesTaxAmount.toFixed(2);
 
    calcTicketPrice = pricePerTicket * numberOfTickets;

    parkingPrice.textContent = "$" + calcPassPrice;
    protectionPrice.textContent = "$" + calcProtectionPrice; 

    totalOfAllPrices = calcTicketPrice + salesTaxAmount + calcPassPrice + calcProtectionPrice;
    orderTotal.textContent = "$" + Math.round(totalOfAllPrices * 100) / 100;  

    totalOfAllPrices = calcTicketPrice + salesTaxAmount + calcPassPrice + calcProtectionPrice;
    totalOfAllPrices = Math.round(totalOfAllPrices * 100) / 100;
    orderTotal.textContent = "$" + totalOfAllPrices.toFixed(2);
}

