
placeOrderButton.addEventListener('click', () => {
    if (slideOneValid && slideTwoValid) {
    
    let confirmationNum = generateConfirmationNumber();
    let orderDate = getFormattedDate();
    let ticketsFor = showPerformers.textContent;

    //see buyer for slide one, see cardinfo for slide two
        const checkoutData = {
            email: checkoutEmail.value,
            firstName: firstName.value,
            lastName: lastName.value,
            phone: phone.value,
            address: address.value,
            city: city.value,
            state: state.value,
            zip: zip.value,
            cardNumber: cardNumber.value,
            expirationMonth: expirationMonth.value,
            expirationYear: expirationYear.value,
            cvv: cvv.value,
            confirmationNumber: confirmationNum,
            ticketPrice: calcTicketPrice,
            salesTax: salesTaxAmount,
            passPrice: calcPassPrice,
            protectionPrice: calcProtectionPrice,
            orderTotal: totalOfAllPrices,
            orderDate: orderDate,
            section: currentSection,
            row: currentRow,
            tickets: ticketSelect.value,
            ticketEvent: ticketsFor,
            user: user.value,
            pass: pass.value
        }
        
        console.log(checkoutData);

        //Send data
        fetch('http://localhost:8080/api/checkout', {  //Replace these :8080/as/needed
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(checkoutData),
        }).then(response => response.text())
                .then(data => alert(data))
                .catch(error => console.error('Error:', error));  

    }
    //display confirmation number/success status - get rid of close overlay,
    //& redirect user to homepage

    //or... reset cart
    closeOverlay();
    listings.innerHTML = '';
    //blankTicket.classList.remove('hide');

})
   
const user = document.getElementById('user');
const pass = document.getElementById('pass');

accBtn = document.getElementById('accBtn');

accBtn.addEventListener('click', () => {
    const userStr = user.value;
    const passStr = pass.value;

    checkUserCredentials(userStr, passStr);
});

async function checkUserCredentials(user, pass) {
    try {
        const response = await fetch(`/api/checkout/account/${encodeURIComponent(user)}/${encodeURIComponent(pass)}`);
        if (!response.ok) {
            console.error("Server error:", response.status);
            return;
        }
        const match = await response.json(); // match will be a number
        if (match > 0) {
            console.log("✅ User found");
        } else {
            console.log("❌ No match");
        }
    } catch (err) {
        console.error("Fetch error:", err);
    }
}


