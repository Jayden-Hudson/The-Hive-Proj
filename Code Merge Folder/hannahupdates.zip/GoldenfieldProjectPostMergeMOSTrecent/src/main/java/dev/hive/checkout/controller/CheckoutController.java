package dev.hive.checkout.controller;

import dev.hive.checkout.entity.Checkout;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.web.bind.annotation.*;

import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

import java.math.BigDecimal;
import java.sql.*;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
public class CheckoutController {

    @Autowired
    private JdbcTemplate jdbcTemplate;
    private int parkingPassRow;

    //Get parkng pass data, update UI to reflect if sold out or not
    @GetMapping("/api/eventparking/{safeId}")
    public ResponseEntity<Checkout> getEventParking(@PathVariable int safeId) {
        //Use eventid for query
        String eventParkingSql = """
                    SELECT soldout AS soldoutEvent
                    FROM public.parkingbyevent
                    WHERE eventid = ?
                """;
        try {
            Checkout result = jdbcTemplate.queryForObject(
                    eventParkingSql,
                    new BeanPropertyRowMapper<>(Checkout.class),
                    safeId
            );
            return ResponseEntity.ok(result);
        } catch (EmptyResultDataAccessException e) {
            return ResponseEntity.notFound().build();
        }
    }

    //Get rows by sectionid & eventid: update UI to load rows by section
    @GetMapping("/api/sections/{sectionId}/{safeId}")
    public List<Checkout> getSectionRows(@PathVariable int sectionId, @PathVariable int safeId) {

        String rowsInSectionSql = """
                    SELECT rownumber AS rowsInSection, ticketsleft AS ticketsInRow, sectionid AS clickedSection, soldout AS soldOutRow
                    FROM public.rowsbyevent
                    WHERE sectionid = ? AND eventid = ?
                    ORDER BY rowid DESC
                """;

        try {
            //Return SELECT values to be handeled by front-end js to update UI
            return jdbcTemplate.query(rowsInSectionSql,
                    new BeanPropertyRowMapper<>(Checkout.class), sectionId, safeId);
        } catch (Exception e) {
            e.printStackTrace();
            return List.of();
        }
    }

    //Check if user credentials match an account at checkout
    @GetMapping("/api/checkout/account/{user}/{pass}")
    public ResponseEntity<Integer> getUserCredentials(@PathVariable String user, @PathVariable String pass) {

        //If user credentials match, COUNT should be = to 1
        String userCredentialsSql = """
                    SELECT COUNT(*)
                    FROM public.account
                    WHERE username = ? AND password = ?
                """;

        try {
            Integer foundRow = jdbcTemplate.queryForObject(userCredentialsSql, Integer.class, user, pass);
            if (foundRow == null) foundRow = 0;
            //Return value to front-end to be handeld in js
            return ResponseEntity.ok(foundRow);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(500).body(0);
        }
    }

    //Get sold out sections for the selected event
    @GetMapping("/api/soldout/sections/{sectionId}/{eventId}")
    //Determine sold out section by: if each row in the selected section is sold out
    public boolean isSectionSoldOut(@PathVariable int sectionId, @PathVariable int eventId) {
        String sql = """
                    SELECT COUNT(*)
                    FROM public.rowsbyevent 
                    WHERE sectionid = ? AND eventid = ? AND soldout = TRUE
                """;

        try {
            //Return boolean to update UI if a row or entire section is sold out
            Integer soldOutCount = jdbcTemplate.queryForObject(sql, Integer.class, sectionId, eventId);
            if (soldOutCount == null) {
                return false;
            }
            //3 default rows/section - if all are sold out, return true
            if (soldOutCount == 3) {
                return true;
            }
            //Extra check: GA section has one row, check if sectionid is GA section
            if (sectionId == 8 && soldOutCount >= 1) {
                return true;
            }
            return false;
        } catch (Exception e) {
            System.err.println("Error getting sold out sections: " + e.getMessage());
            return false;
        }
    }

    //Get all data entered at checkout
    @PostMapping("/api/checkout")
    public String addCheckoutData(@RequestBody Checkout checkout) {

        ////////////////////////////////////////////DELETE
        //for testing: compared getter value to console value to db value
        /*
        System.out.println("Received data for checkout order# " + checkout.getConfirmationNumber());
        System.out.println("Tickets for " + checkout.getTicketEvent());*/

        try {
            //First: Insert data into buyer table, return buyerid for fk purposes
            KeyHolder buyerKeyHolder = new GeneratedKeyHolder();

            String buyerSql = """
                    INSERT INTO public.buyer
                    (firstname, lastname, email, phone)
                    VALUES (?, ?, ?, ?)
                    RETURNING buyerid
                """;

            int buyerRows = jdbcTemplate.update(connection -> {
                PreparedStatement ps = connection.prepareStatement(buyerSql, Statement.RETURN_GENERATED_KEYS);
                ps.setString(1, checkout.getFirstName());
                ps.setString(2, checkout.getLastName());
                ps.setString(3, checkout.getEmail());
                ps.setString(4, checkout.getPhone());
                return ps;
            }, buyerKeyHolder);

            //Check if buyerid is retireved
            Number buyerid = buyerKeyHolder.getKey();
            if (buyerid == null) {
                throw new RuntimeException("Failed to retrieve generated buyer ID");
            }

            //Second: insert card info data into cardinfo table, insert buyerid
            String cardInfoSql = """
                    INSERT INTO public.cardinfo
                    (cardnum, expirationmonth, cvv, address, city, state, zip, expirationyear, buyerid)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """;

            int cardInfoRows = jdbcTemplate.update(connection -> {
                PreparedStatement ps = connection.prepareStatement(cardInfoSql, Statement.RETURN_GENERATED_KEYS);
                ps.setString(1, checkout.getCardNumber());
                ps.setString(2, checkout.getExpirationMonth());
                ps.setString(3, checkout.getCvv());
                ps.setString(4, checkout.getAddress());
                ps.setString(5, checkout.getCity());
                ps.setString(6, checkout.getState());
                ps.setString(7, checkout.getZip());
                ps.setString(8, checkout.getExpirationYear());
                ps.setInt(9, buyerid.intValue());
                return ps;
            });


            //Third: get userid from account table if user linked account at checkout
            Integer userId = null;

            String userIdSql = """
                SELECT userid
                FROM public.account
                WHERE username = ? AND password = ?
            """;

            try {
                //If there is a username/password match, set userid for fk purposes in orders table
                userId = jdbcTemplate.queryForObject(
                        userIdSql,
                        Integer.class,
                        checkout.getUser(),
                        checkout.getPass()
                );
            } catch (EmptyResultDataAccessException e) {
                System.err.println("Error retrieving userid" + e.getMessage());
            }

            //Fourth: insert into orders table, return the orderid
            KeyHolder orderKeyHolder = new GeneratedKeyHolder();

            String orderSql = """
                    INSERT INTO public.orders
                    (confirmationnum, ticketprice, salestax, passprice, protectionprice, ordertotal, orderdate, buyerid, userid)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                    RETURNING orderid
                """;

            Integer finalUserId = userId;

            int orderRows = jdbcTemplate.update(connection -> {
                PreparedStatement ps = connection.prepareStatement(orderSql, Statement.RETURN_GENERATED_KEYS);
                ps.setString(1, checkout.getConfirmationNumber());
                ps.setBigDecimal(2, checkout.getTicketPrice());
                ps.setBigDecimal(3, checkout.getSalesTax());
                ps.setBigDecimal(4, checkout.getPassPrice());
                ps.setBigDecimal(5, checkout.getProtectionPrice());
                ps.setBigDecimal(6, checkout.getOrderTotal());
                ps.setString(7, checkout.getOrderDate());
                ps.setInt(8, buyerid.intValue());

                //Allow userid to be null in orders table
                if (finalUserId != null) {
                    ps.setInt(9, finalUserId);
                } else {
                    ps.setNull(9, Types.INTEGER);
                }
                return ps;
            }, orderKeyHolder);

            ////////////////////////////////////////////DELETE
            /*
            int orderRows = jdbcTemplate.update(connection -> {
                PreparedStatement ps = connection.prepareStatement(orderSql, Statement.RETURN_GENERATED_KEYS);
                ps.setString(1, checkout.getConfirmationNumber());
                ps.setBigDecimal(2, checkout.getTicketPrice());
                ps.setBigDecimal(3, checkout.getSalesTax());
                ps.setBigDecimal(4, checkout.getPassPrice());
                ps.setBigDecimal(5, checkout.getProtectionPrice());
                ps.setBigDecimal(6, checkout.getOrderTotal());
                ps.setString(7, checkout.getOrderDate());
                ps.setInt(8, buyerid.intValue());
                return ps;
            }, orderKeyHolder); */


            //Get orderid for fk purposes
            Number orderid = orderKeyHolder.getKey();
            if (orderid == null) {
                throw new RuntimeException("Failed to retrieve generated buyer ID");
            }

            ///////////////////////////////////////////////DELETE
            /* //////////////////////
            Get the event (eventid) user bought tickets for(DONE)
            Use this to complete the NEXT steps (NOT DONE)
            ////////////////////// */
            // TO-DO: update rowsByEvent table (subtract number of tickets purchased from the corresponding row for that event(& track sold out status)
            // DONE: if user bought a parking pass, add row to parkingPass table for that order
            // TO-DO: update parkingByEvent table (subtract a pass from the number of passes left(& track sold out status)

            //Fifth: Get the eventid being viewed at ticket selection/checkout to update other linked tables
            String getEventSql = """
                        SELECT eventid 
                        FROM public.event 
                        WHERE title = ?
                    """;

            //Query for eventid
            Optional<Integer> idOfEvent = jdbcTemplate.query(getEventSql,
                    new Object[]{checkout.getTicketEvent()},
                    rs -> {
                        if (rs.next()) {
                            return Optional.of(rs.getInt("eventid"));
                        }
                        return Optional.empty();
                    }
            );

            //Set primitive
            int eventid = idOfEvent.orElse(0);

            /*         USE TRY CATCH?
            try {
                Optional<Integer> idOfEvent = jdbcTemplate.query(
                    getEventSql,
                    new Object[]{checkout.getTicketEvent()},
                    rs -> rs.next() ? Optional.of(rs.getInt("eventid")) : Optional.empty()
                );
                    int eventid = idOfEvent.orElse(0);
            } catch (DataAccessException e) {
                log.error("error fetching eventid", e);
                eventid = 0; // fallback }
             */

            ///////////////////////////////////////////////////DELETE
            /*
            if (eventid > 0) {
                System.out.println("Event ID: " + eventid);
            } else {
                System.out.println("Event ID: not found");
            }*/

            //Sixth: Use retrieved eventid for parkingpass table insert
            String parkingPassSql = """
                INSERT INTO public.parkingpass
                (price, orderid, eventid)
                VALUES (?, ?, ?)
            """;

            //Pass purchased is true if pass price of the order was greater than 0
            if (checkout.getPassPrice().compareTo(BigDecimal.ZERO) > 0 && eventid > 0) {
                parkingPassRow = jdbcTemplate.update(connection -> {
                    PreparedStatement ps = connection.prepareStatement(parkingPassSql);
                    ps.setBigDecimal(1, checkout.getPassPrice());
                    ps.setInt(2, orderid.intValue());
                    ps.setInt(3, eventid);
                    return ps;
                });
            }

            /////////////////////////////////////////DELETE
            //First: take tix section/row data & query for the rowid of the row in rows table
            //Second: use retrieved rowid to identify the record whose id(rowid, eventid) matches
            // the row & event of the tix
            //Next: update the identified record: decrement ticketsavailable by - ticket quantity
            // for that row during the correct event

            //Seventh: Get the rowid of the row tickets were pruchased from to update linked tables
            String ticketRowSectionSql = """
                    SELECT rowid 
                    FROM public.rows
                    WHERE rownumber = ? AND sectionid = ?
                    """;

            Map<String, Object> staticRow = jdbcTemplate.queryForMap(
                    ticketRowSectionSql,
                    checkout.getRow(),
                    checkout.getSection()
            );

            Integer rowIdValue = (Integer) staticRow.get("rowid");

            ///////////////////////////////////////////////DLETE
            //TESTing
            //System.out.println("Row ID: " + rowIdValue);

            //Eighth: Get record from rowsbyevent table where rowid & eventid match order data
            String ticketRowEventSql = """
                    SELECT ticketsleft
                    FROM public.rowsbyevent
                    WHERE rowid = ? AND eventid = ?
                    LIMIT 1
                    """;

            //Query for ticketsleft in the dynamic table
            Map<String, Object> dynamicTixRow = jdbcTemplate.queryForMap(
                    ticketRowEventSql,
                    rowIdValue,
                    eventid
            );

            /////////////////////////////////////////DELTE
            //TO DELTE - TESTING
            /*
            System.out.println("Row retrieved:");
            for (Map.Entry<String, Object> entry : dynamicTixRow.entrySet()) {
                System.out.println(entry.getKey() + " = " + entry.getValue());
            }*/

            ////////////////////////////////////////////////////////////////////////DELETE
            //NEXT: DONE -> update parkingbyevent (DONE) & rowsbyevent (DONE)
            //NEXT: code to check if passessold = passesavailabe, set soldout to true, reflect in ui
            //NEXT: code to check if tixketsleft = 0, set soldout to true, reflect in ui

            //Ninth: Get int value from ticketsleft column & number of tickets included in the order
            int ticketsLeft = ((Number) dynamicTixRow.get("ticketsleft")).intValue();
            int ticketsToBuy = checkout.getTickets();

            if (ticketsToBuy <= 0) {
                throw new IllegalArgumentException("Number of tickets to buy must be positive.");
            }
            if (ticketsLeft < ticketsToBuy) {
                throw new IllegalStateException("Not enough tickets available.");
            }

            //Use int values to update rowsbyevent table & set row as sold out if case check is true
            String updateRowsTable = """
                    UPDATE public.rowsbyevent
                    SET ticketsleft = ticketsleft - ?,
                        soldout = CASE
                                     WHEN ticketsleft - ? = 0 THEN TRUE
                                     ELSE soldout 
                                  END
                        WHERE rowid = ? AND eventid = ?
                    """;

            int tixRowsUpdated = jdbcTemplate.update(
                    updateRowsTable,
                    ticketsToBuy,  //decrement ticketsleft
                    ticketsToBuy,  //case check
                    rowIdValue,
                    eventid
            );

            //Tenth: Update event table, increment the number of tickets sold, and compare to total tickets available
            //Event is sold out when number of tickets sold is equal to the total tickets available
            String sql = """
                        UPDATE public.event
                        SET eventticketssold = eventticketssold + ?,
                            eventsoldout = (eventticketssold + ?) >= totaltickets
                        WHERE eventid = ?
                    """;

            //Use number of tickets purchased to increment eventitcketssold
            int eventTixUpdated = jdbcTemplate.update(
                    sql,
                    ticketsToBuy,   //eventticketssold increment
                    ticketsToBuy,   //sold out check
                    eventid         //WHERE
            );

            ////////////////////////////////////////////////////////////////DELETE
            /*
            if (eventTixUpdated > 0) {
                System.out.println("event tickets succesfully sold");
            }*/

            if (tixRowsUpdated == 0) {
                throw new IllegalStateException("Event row unable to be updated");
            }

            ////////////////////////////////////////////DELETE
            //System.out.println("Tickets successfully decremented. Remaining: " + (ticketsLeft - ticketsToBuy));

            //Eleventh: Update parkingbyevent table if pass was purchased (true if pass price was greater than 0 in the order)
            BigDecimal passPurchased = checkout.getPassPrice();

            if (passPurchased != null && passPurchased.compareTo(BigDecimal.ZERO) > 0) {
                String updateParkingTable = """
                            UPDATE public.parkingbyevent
                            SET passessold = passessold + 1,
                                soldout = (passessold + 1) >= passesavailable
                            WHERE eventid = ?
                        """;

                int parkingRowsUpdated = jdbcTemplate.update(updateParkingTable, eventid);

                ///////////////////////////////////////Could be deleted!
                if (parkingRowsUpdated > 0) { //here
                    System.out.println("Successfully updated passessold for eventId: " + eventid);
                } else {
                    System.out.println("No rows updated. Check if eventId exists.");
                } //to here

            } else {
                System.out.println("Pass price is zero or negative. No update performed.");
            }

            ///////////////////////////////////////DELETE
            /* For testing
            String parkingRowEventSql = """
                    SELECT passessold, passesavailable
                    FROM public.parkingbyevent
                    WHERE eventid = ?
                    """;

            Map<String, Object> dynamicParkingRow = jdbcTemplate.queryForMap(
                    parkingRowEventSql,
                    eventid
            );

            dynamicParkingRow.forEach((key, value) ->
                    System.out.println(key + " = " + value));
            */

            ////////////////////////////////////DELETE
            //for testing purposes
            /*
            System.out.println("Buyer rows inserted: " + buyerRows);
            System.out.println("Card info rows inserted: " + cardInfoRows);
            System.out.println("Order rows inserted: " + orderRows);
            System.out.println("Parking pass rows inserted: " + parkingPassRow);
             */

            return (cardInfoRows > 0 && buyerRows > 0 && orderRows > 0)
                    ? "Data inserted successfully"
                    : "Insert failed";

        } catch (Exception e) {
            e.printStackTrace();
            return "Error inserting data: " + e.getMessage();
        }
    }
}



