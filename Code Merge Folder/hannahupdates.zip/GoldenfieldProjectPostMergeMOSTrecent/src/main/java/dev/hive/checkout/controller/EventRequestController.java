package dev.hive.checkout.controller;

import dev.hive.checkout.entity.EventRequest;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.List;

@RestController
public class EventRequestController {
    @Autowired
    private JdbcTemplate jdbcTemplate;

    //Post for event request data
    @PostMapping("/api/eventrequest")
    public String addEventData(@RequestBody EventRequest event) {

        //All requests are not processed at time of submission
        boolean requestProcessed = false;

        try {

            //Set up to retrieve primary key
            KeyHolder keyHolder = new GeneratedKeyHolder();

            //First: insert event data into eventrequest table
            String eventSql = """
                        INSERT INTO public.eventrequest
                        (eventtype, performers, expectedattendance, agerange, additionaleventdetails, eventbudget, starttime, startdate, requestprocessed)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                        RETURNING requestid
                    """;

            jdbcTemplate.update(connection -> {
                PreparedStatement ps = connection.prepareStatement(eventSql, Statement.RETURN_GENERATED_KEYS);
                ps.setString(1, event.getEventType());
                ps.setString(2, event.getPerformers());
                ps.setString(3, event.getAttendance());
                ps.setString(4, event.getAges());
                ps.setString(5, event.getEventDetails());
                ps.setString(6, event.getBudget());
                ps.setString(7, event.getStartTime());
                ps.setString(8, event.getStartDate());
                ps.setBoolean(9, requestProcessed);
                return ps;
            }, keyHolder);

            //Get the generated event requestid for fk purposes
            Number requestid = keyHolder.getKey();
            if (requestid == null) {
                throw new RuntimeException("Failed to retrieve generated event ID");
            }

            //Second: insert the form's contact details into contact info table
            String contactSql = """
                        INSERT INTO public.contactinfo
                        (companyname, contactfirstname, contactlastname, phone, email, besttimetobereached, links, additionalcontactnotes, requestid)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """;

            int contactRows = jdbcTemplate.update(contactSql,
                    event.getCompany(),
                    event.getFirstName(),
                    event.getLastName(),
                    event.getPhone(),
                    event.getEmail(),
                    event.getContactTime(),
                    event.getLinks(),
                    event.getContactNotes(),
                    requestid.intValue());

            return contactRows > 0 ? "Event request submission successful" : "Error: Event request submission unsuccessful. Request not received. ";
        } catch (Exception e) {
            e.printStackTrace();
            return "Error proccessing event request: " + e.getMessage();
        }
    }

    //Get event request data for displaying in event creation
    @GetMapping("/api/eventrequests")
    public List<EventRequest> getAllEventRequests() {
        String selectEventSql = """
                SELECT * FROM public.eventrequest
                """;

        return jdbcTemplate.query(selectEventSql, (rs, rowNum) -> {
            EventRequest event = new EventRequest();
            event.setEventType(rs.getString("eventtype"));
            event.setPerformers(rs.getString("performers"));
            event.setAttendance(rs.getString("expectedattendance"));
            event.setAges(rs.getString("agerange"));
            event.setEventDetails(rs.getString("additionaleventdetails"));
            event.setBudget(rs.getString("eventbudget"));
            event.setStartTime(rs.getString("starttime"));
            event.setStartDate(rs.getString("startdate"));
            event.setRequestProcessed(rs.getBoolean("requestprocessed"));
            return event;
        });
    }

    //Get event request data by ID
    @GetMapping("/api/eventrequests/{id}")
    public EventRequest getEventById(@PathVariable int id) {
        String eventByIdSql = """
                SELECT * FROM public.eventrequest WHERE requestid = ?
                """;
        try {
            return jdbcTemplate.queryForObject(eventByIdSql, (rs, rowNum) -> {
                EventRequest event = new EventRequest();
                event.setEventType(rs.getString("eventtype"));
                event.setPerformers(rs.getString("performers"));
                event.setAttendance(rs.getString("expectedattendance"));
                event.setAges(rs.getString("agerange"));
                event.setEventDetails(rs.getString("additionaleventdetails"));
                event.setBudget(rs.getString("eventbudget"));
                event.setStartTime(rs.getString("starttime"));
                event.setStartDate(rs.getString("startdate"));
                event.setRequestProcessed(rs.getBoolean("requestProcessed"));
                return event;
            }, id);

        } catch (Exception e) {
            throw new RuntimeException("Event not found with id: " + id);
        }
    }
}