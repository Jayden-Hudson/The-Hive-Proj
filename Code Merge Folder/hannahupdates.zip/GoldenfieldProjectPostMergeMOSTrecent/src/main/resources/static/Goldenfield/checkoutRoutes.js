//Event listener for placing an order
placeOrderButton.addEventListener('click', () => {
    if (slideOneValid && slideTwoValid) {
    
    let confirmationNum = generateConfirmationNumber();
    let orderDate = getFormattedDate();
    let ticketsFor = showPerformers.textContent;

    //if one input is empty, make sure to clear the other
    if (user.value == '') {
        pass.value == '';
    }

     if (pass.value == '') {
            user.value == '';
     }

    //checkout data gathered
        const checkoutData = {
            email: checkoutEmail.value,
            firstName: firstName.value,
            lastName: lastName.value,
            phone: phone.value,
            address: address.value,
            city: city.value,
            state: state.value,
            zip: zip.value,
            cardNumber: cardNumber.value,
            expirationMonth: expirationMonth.value,
            expirationYear: expirationYear.value,
            cvv: cvv.value,
            confirmationNumber: confirmationNum,
            ticketPrice: calcTicketPrice,
            salesTax: salesTaxAmount,
            passPrice: calcPassPrice,
            protectionPrice: calcProtectionPrice,
            orderTotal: totalOfAllPrices,
            orderDate: orderDate,
            section: currentSection,
            row: currentRow,
            tickets: ticketSelect.value,
            ticketEvent: ticketsFor,
            user: user.value,
            pass: pass.value
        }


        //Send checkout data
        fetch('http://localhost:8080/api/checkout', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(checkoutData),
        }).then(response => response.text())
                .then(data => alert(data))
                .catch(error => console.error('Error:', error));  

    }

    closeOverlay();
    listings.innerHTML = '';

    //IF successful.... display an alert first
    window.location.reload();

})
   
//check username and password if user clicks 'find account' button
accBtn.addEventListener('click', (e) => {
    e.preventDefault();
    const userStr = user.value;
    const passStr = pass.value;

    checkUserCredentials(userStr, passStr);
});

//fetch - check if username and password was a match
async function checkUserCredentials(userStr, passStr) {
    try {
        const response = await fetch(`/api/checkout/account/${encodeURIComponent(userStr)}/${encodeURIComponent(passStr)}`);
        if (!response.ok) {
            console.error("Server error:", response.status);
            return;
        }
        const match = await response.json();
        if (match > 0) {

            alert('Account found!');

        } else {
            alert('Invalid username or password.')
            user.value = '';
            pass.value = '';
        }
    } catch (err) {
        console.error("Fetch error:", err);
    }
}


