const daysList = document.getElementById('days');
const monthYear = document.getElementById('month-year');
const prevMonthBtn = document.getElementById('previous-month');
const nextMonthBtn = document.getElementById('next-month');

const els = {
  eventList: document.getElementById('eventList'),
  requestList: document.getElementById('requestList'),
  refreshEvents: document.getElementById('refreshEvents'),
  refreshRequests: document.getElementById('refreshRequests'),
  createForm: document.getElementById('createForm'),
  title: document.getElementById('title'),
  description: document.getElementById('description'),
  eventdate: document.getElementById('eventdate'),
  eventtime: document.getElementById('eventtime'),
  venueid: document.getElementById('venueid'),
  updateForm: document.getElementById('updateForm'),
  updatedEventID: document.getElementById('updatedEventID'),
  updatedTitle: document.getElementById('updatedTitle'),
  updatedDescription: document.getElementById('updatedDescription'),
  updatedEventDate: document.getElementById('updatedEventDate'),
  updatedEventTime: document.getElementById('updatedEventTime'),
  updatedVenueID: document.getElementById('updatedVenueID'),
  cancelForm: document.getElementById('cancelForm'),
  cancelledTitle: document.getElementById('cancelledTitle'),
  cancelledEventID: document.getElementById('cancelledEventID'),
};

let eventsCache = [];
let eventRequestsCache = [];

//pads numbers used in dates to ensure two-digit format to fit iso format which works with calendar
function pad(n) { return n < 10 ? '0' + n : String(n); }

document.addEventListener('DOMContentLoaded', () => {
  els.refreshEvents = els.refreshEvents || document.getElementById('refreshEvents');
  els.refreshRequests = els.refreshRequests || document.getElementById('refreshRequests');

  if (els.refreshEvents) {
    els.refreshEvents.addEventListener('click', () => fetchEvents());
  }

  if (els.refreshRequests) {
    els.refreshRequests.addEventListener('click', () => fetchEventRequests());
  }

  fetchEvents();
  fetchEventRequests();
});

// ==========================================
// Fetching Event Data for Lists and Calendar
// ==========================================

// Fetch events from database to show on eventList + calendar
async function fetchEvents() {
  try {
    const res = await fetch('http://localhost:8080/api/events');
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();

    //put all event info into eventsCache array
    eventsCache = Array.isArray(data) ? data : [];

    if (els.eventList) {

      els.eventList.innerHTML = '';

      if (eventsCache.length === 0) {
        const li = document.createElement('li');
        li.textContent = 'No events.';
        els.eventList.appendChild(li);
      }

      else {
        for (const ev of eventsCache) {
          els.eventList.appendChild(renderEvent(ev));
        }
      }
    }

    try { renderCalendar(); } catch (e) { }

  } catch (err) {
    console.error('Failed to fetch events', err);
  }

  try { populateCancelFormDropdown(); } catch (e) { }
  try { populateUpdateFormDropdown(); } catch (e) { }
}

// Fetch events from event request tables to show on event requests
async function fetchEventRequests() {
  try {
    const res = await fetch('http://localhost:8080/api/eventrequests');
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();

    //put all event info into eventsCache array
    eventRequestsCache = Array.isArray(data) ? data : [];

    if (els.requestList) {

      els.requestList.innerHTML = '';

      if (eventRequestsCache.length === 0) {
        const li = document.createElement('li');
        li.textContent = 'No event requests.';
        els.requestList.appendChild(li);
      }

      else {
        for (const ev of eventRequestsCache) {
          els.requestList.appendChild(renderRequest(ev));
        }
      }
    }

    try { populateCreateFormDropdown(); } catch (e) { }
    try { renderCalendar(); } catch (e) { }

  } catch (err) {
    console.error('Failed to fetch event requests', err);
  }
}

// ==========================================
// Submitting Forms
// ==========================================

//submit event creation form
createForm.addEventListener('submit', function (event) {
  event.preventDefault(); 

  const eventData = {
    title: els.title.value,
    description: els.description.value,
    eventdate: els.eventdate.value,
    eventtime: els.eventtime.value,
    venueid: els.venueid.value
  }

  fetch('http://localhost:8080/api/ECreation', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(eventData),
  }).then(response => response.text())
    .then(data => alert(data))
    .then(() => {
      try { fetchEvents(); } catch (e) { }
    })
    .catch(error => console.error('Error:', error));
});

//update existing event
updateForm.addEventListener('submit', function (event) {
  event.preventDefault(); 

  const eventData = {
    title: els.updatedTitle.value,
    description: els.updatedDescription.value,
    eventdate: els.updatedEventDate.value,
    eventtime: els.updatedEventTime.value,
    venueid: els.updatedVenueID.value
  }

  const updatedID = els.updatedEventID.value.trim();

  if (!updatedID) {
    showMessage('You must select an event', true);
    return;
  }

  const matches = eventsCache.filter(
    ev => String(updatedID) === String(ev.eventid)
  );

  if (matches.length === 0) {
    alert(`No event found with ID "${updatedID}"`);
    return;
  }

  //get event id from database, always uses the first match if there are multiple events with the same title
  let id = matches[0].eventid;

  fetch(`http://localhost:8080/api/events/${id}`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(eventData),
  }).then(response => response.text())
    .then(data => alert(data))
    .then(() => {
      try { fetchEvents(); } catch (e) { }
    })
    .catch(error => console.error('Error:', error));
});

//cancel an event
cancelForm.addEventListener('submit', function (event) {
  event.preventDefault(); 

  const id = document.getElementById('cancelledEventID').value;
  if (!id) {
    return;
  }

  let eventcancelled = null;
  const selectedStatus = cancelForm.eventStatus.value;
  if (selectedStatus && selectedStatus === 'cancel') {
    eventcancelled = true;
  } else if (selectedStatus && selectedStatus === 'activate') {
    eventcancelled = false;
  }

  if (eventcancelled === null) {
    showMessage('Please choose Cancel or Activate', true);
    return;
  }

  fetch(`http://localhost:8080/api/events/${id}/cancel`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
    },
  body: JSON.stringify({ eventcancelled: eventcancelled }),
  }).then(response => response.text())
    .then(data => alert(data))
    .then(() => {
      try { fetchEvents(); } catch (e) { }
    })
    .catch(error => console.error('Error:', error));
});

//validate event data
function validateEvent(obj) {
  const errors = [];
  const title = (obj.title || '').trim();
  if (title && !/^.{1,}$/.test(title)) {
    errors.push('title must be a string with at least 1 character');
  }

  const description = (obj.description || '').trim();
  if (description && !/^.{1,}$/.test(description)) {
    errors.push('description must be a string with at least 1 character');
  }

  const date = (obj.eventdate || '').trim();
  if (date && !/^\d{4}-\d{2}-\d{2}$/.test(date)) {
    errors.push('eventdate must be YYYY-MM-DD');
  }

  const time = (obj.eventtime || '').trim();
  if (time && !/^\d{1,2}[:]{1}\d{2}$/.test(time)) {
    errors.push('eventtime must be HH:MM');
  }

  const venueid = (obj.venueid || '');
  if (venueid && isNaN(Number(venueid))) {
    errors.push('venueid must be numeric');
  }

  return { valid: errors.length === 0, errors };
}

// ==========================================
// Rendering Event and Event Request Lists
// ==========================================

// Render items as eventList
function renderEvent(item) {
  // make the listed event clickable and focusable
  const li = document.createElement('li');
  li.classList.add("individualItem");
  li.setAttribute('role', 'button');
  li.style.cursor = 'pointer';
  const title = `${item.title} --`;
  const description = ` Description: ${item.description},`;
  const eventdate = ` Event Date: ${item.eventdate},`;
  const eventtime = ` Event Time: ${item.eventtime},`;
  const venueid = ` Venue ID: ${item.venueid}`;
  li.textContent = `${title}${description}${eventdate}${eventtime}${venueid}`;

  // click on event from list and populate update form
  li.addEventListener('click', () => {
  // use the event id to populate the form
  populateUpdateFormByDropdown(item.eventid);
    //focus onto the title field so user can edit form before submitting
    const titleEl = document.getElementById('updatedTitle');
    if (titleEl) titleEl.focus();
  });
  return li;
}

function renderRequest(item) {
  const li = document.createElement('li');
  // make the list item clickable and focusable
  li.classList.add("individualItem");
  li.setAttribute('role', 'button');
  li.style.cursor = 'pointer';
  const eventType = `${item.eventType} --`;
  const performers = ` Performers: ${item.performers},`;
  const attendance = ` Attendance: ${item.attendance},`;
  const ages = ` Ages: ${item.ages},`;
  const eventDetails = ` Event Details: ${item.eventDetails},`;
  const budget = ` Budget: ${item.budget},`;
  const startTime = ` Start Time: ${item.startTime},`;
  const startDate = ` Start Date: ${item.startDate},`;
  li.textContent = `${eventType}${performers}${attendance}${ages}${eventDetails}${budget}${startTime}${startDate}`;

  // click on event from list and populate event creation form
  li.addEventListener('click', () => {
    //use performers and dropdown to populate the form
    populateCreateFormByDropdown(item.performers);
    //focus onto the title field so user can edit form before submitting
    const titleEl = document.getElementById('title');
    if (titleEl) titleEl.focus();
  });

  return li;
}

// ==========================================
// Populating Form Dropdowns
// ==========================================

//populate create form dropdown with event request performers
async function populateCreateFormDropdown() {
  const dropdown = document.getElementById('createFormData-dropdown');

  try {
    const items = eventRequestsCache;

    dropdown.innerHTML = '<option value="">Select an option</option>';

    //loop through data and create option elements
    items.forEach(item => {
      const option = document.createElement('option');
      option.textContent = item.performers;
      dropdown.appendChild(option);
    });
  } catch (error) {
    console.error('Error fetching data:', error);
  }
}

//populate create form using dropdown input
function populateCreateFormByDropdown(selectedOption) {
  const form = document.getElementById('createForm');
  if (!form) return;

  const data = eventRequestsCache.find(item => item.performers === selectedOption);
  if (!data) return;

  form.title.value = data.performers || '';
  form.description.value = data.eventDetails || '';
  form.eventdate.value = data.startDate || '';
}

//populate update form dropdown with event data
async function populateUpdateFormDropdown() {
  const dropdown = document.getElementById('updateFormData-dropdown');

  try {
    const items = eventsCache;

    dropdown.innerHTML = '<option value="">Select an option</option>';

    //loop through data and create option elements
    items.forEach(item => {
      const option = document.createElement('option');
      // visible text on dropdown
      option.textContent =
        `${item.title} (${item.eventdate})`;
      // unique hidden value
      option.value = item.eventid;

      dropdown.appendChild(option);
    });
  } catch (error) {
    console.error('Error fetching data:', error);
  }
}

//populate update form using dropdown input
function populateUpdateFormByDropdown(selectedOption) {
  const form = document.getElementById('updateForm');
  if (!form) return;

  const data = eventsCache.find(item => String(item.eventid) === String(selectedOption));

  if (!data) return;

  form.updatedTitle.value = data.title || '';
  form.updatedDescription.value = data.description || '';
  form.updatedEventDate.value = data.eventdate || '';
  form.updatedEventTime.value = data.eventtime || '';
  form.updatedVenueID.value = data.venueid || '';
  form.updatedEventID.value = data.eventid || '';
}

//populate cancel event dropdown with event title
async function populateCancelFormDropdown() {
  const dropdown = document.getElementById('cancelFormData-dropdown');

  try {
    const items = eventsCache;

    dropdown.innerHTML = '<option value="">Select an option</option>';

    //loop through data and create option elements
    items.forEach(item => {
      const option = document.createElement('option');
      // visible text on dropdown
      option.textContent =
        `${item.title} (${item.eventdate})`;
      // unique hidden value
      option.value = item.eventid;

      dropdown.appendChild(option);
    });
  } catch (error) {
    console.error('Error fetching data:', error);
  }
}

//select event to cancel using dropdown
function populateCancelFormByDropdown(selectedOption) {
  const form = document.getElementById('cancelForm');

  // find by event id
  const data = eventsCache.find(
    item => String(selectedOption) === String(item.eventid)
  );

  if (!data) return;

  // fill form fields
  form.cancelledTitle.value = data.title || '';
  form.cancelledEventID.value = data.eventid || '';
}

// ==========================================
// Rendering Calendar
// ==========================================

//creates date using current date provided by user's browser
let date = new Date();

const months = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December'
];

//render item on calendar with title only
function renderEventSmall(item) {
  const el = document.createElement('div');

  el.className = 'eventCreationSmall';

  if (item.eventcancelled === true) {
    el.classList.add('cancelledEvent');
  }

  el.textContent = item.title || '';
  return el;
}

function renderCalendar() {

  daysList.innerHTML = '';

  //get current month and year provided by user's browser
  const month = date.getMonth();
  const year = date.getFullYear();

  monthYear.textContent = `${months[month]} ${year}`;

  const firstDay = new Date(year, month, 1).getDay();
  const lastDate = new Date(year, month + 1, 0).getDate();

  //render empty cells for days before the first day of the month
  for (let i = 0; i < firstDay; i++) {
    const beforeFirstday = document.createElement('div');
    beforeFirstday.classList.add('empty');
    daysList.appendChild(beforeFirstday);
  }

  //render all days in the month
  for (let day = 1; day <= lastDate; day++) {
    const cell = document.createElement('div');
    cell.className = 'calendarDay';

    //display date number on day box
    const dayNumber = document.createElement('div');
    dayNumber.className = 'dayNumber';
    dayNumber.textContent = day.toString();
    cell.appendChild(dayNumber);

    //pad numbers used in dates to ensure two-digit format to fit iso format which works with calendar
    const iso = `${year}-${pad(month + 1)}-${pad(day)}`;

    //create new array and filter for specific day
    const dayEvents = eventsCache.filter(event => {
      if (!event) return false;
      let date = event.eventdate;
      if (!date) return false;
      //make sure eventdate is a string
      if (typeof date !== 'string') date = String(date);
      //compare eventdate (without time) to iso to find matching events
      return date.split('T')[0] === iso;
    });

    //check if there are events for the day, then render them
    if (dayEvents.length > 0) {
      const container = document.createElement('div');
      container.className = 'creationDayEventsContainer';
      for (const event of dayEvents) {
        const small = renderEventSmall(event);
        container.appendChild(small);
      }
      cell.appendChild(container);
    }

    daysList.appendChild(cell);
  }
}

//buttons to move to next/previous month
prevMonthBtn.addEventListener('click', () => {
  date.setMonth(date.getMonth() - 1);
  renderCalendar();
});

nextMonthBtn.addEventListener('click', () => {
  date.setMonth(date.getMonth() + 1);
  renderCalendar();
});

renderCalendar();