

 //eventrequests
  fetch("http://localhost:8080/api/dashboard")
   .then(res => res.json())
   .then(data => {

       let html = '';
       data.forEach(item => {
           html += `
           <tr>
               <td>${item.eventtype}</td>
               <td>${item.performers}</td>
               <td> ${item.expectedattendance}</td>
               <td>${item.agerange}</td>
               <td> ${item.eventbudget}</td>
               <td> ${item.starttime}</td>
               <td> ${item.startdate}</td>
               <td>${item.additionaleventdetails}</td>
           </tr>
           `;
       });

       document.getElementById("eventRequestListTable").innerHTML = html;

   })
   .catch(error => console.log(error));

//buyers table
fetch("http://localhost:8080/api/buyers")
.then(res => res.json())
.then(data => {

    let html = '';

    data.forEach(item => {
        html += `
            <tr>
                <td>${item.firstname} ${item.lastname}</td>
                <td>${item.email}</td>
                <td>${item.phone}</td>
            </tr>
        `;
    });

    document.getElementById("CustomerListTable").innerHTML = html;

})
.catch(error => console.log(error));




//soldout tickets
/*
function loadEventStats(eventId) {

    fetch(`http://localhost:8080/api/event/${eventId}/stats`)
        .then(res => res.json())
        .then(data => {

            document.getElementById("eventStatus").innerText =
                data.soldOut ? "SOLD OUT" : "AVAILABLE";
        })
        .catch(err => console.error(err));
}

*/


//employee table
fetch("http://localhost:8080/api/employees/dashboard")
.then(res => res.json())
.then(data => {

    let html = '';

    data.forEach(item => {
        html += `
            <tr>
                <td>${item.firstname} ${item.lastname}</td>
                <td>${item.employeecode}</td>
                <td>${item.departmentname}</td>

            </tr>
        `;
    });

    document.getElementById("EmployeeList").innerHTML = html;

})
.catch(error => console.log(error));





//orders(transactions)
fetch("http://localhost:8080/api/orders")
.then(res => res.json())
.then(data => {

    let html = '';

    let max = Math.max(...data.map(x => x.ordertotal));
/* <p>orderId: ${item.orderid}</p> */
    //data.forEach(item => {
    //show only 18
    data.slice(0,18).forEach((item,index)=>{

          let height = (item.ordertotal / max) * 300;

                const date = new Date(item.orderdate);
                const month = date.toLocaleString('default', { month:'long' });

                html += `
                    <div class="bar-box">
                        <div class="bar" style="height:${height}px">
                         <span class="totalbar-text">$${item.ordertotal}</span>

                        </div>

                        <small>${month}</small>
                        <br>

                    </div>
                `;
    });

     document.getElementById("ordersBar").innerHTML = html;



       // calculate revenue by year and ticketssold

             let ticketsSold = data.length;
                document.getElementById("ticketsSold").innerText = ticketsSold;

                // capacity)
                let totalCapacity = 1000;
                let ticketsAvailable = totalCapacity - ticketsSold;

                document.getElementById("ticketsAvailable").innerText = ticketsAvailable;


          // revenue
          const currentYear = new Date().getFullYear();
          let totalRevenue = 0;

          data.forEach(order => {
              const date = new Date(order.orderdate);
              if (date.getFullYear() === currentYear) {
                  totalRevenue += order.ordertotal;
              }
          });

          document.getElementById("currentYear").innerText = currentYear;
          document.getElementById("yearRevenue").innerText =
              `$${totalRevenue.toLocaleString()}`;



 })
 .catch(error => console.log(error));


    //where userid is 8
       const userid = 8;

       fetch(`http://localhost:8080/api/orders/${userid}`)
       .then(res => res.json())
       .then(data => {

           let html = '';

           data.forEach(item => {
           html += `
                     <div class="order-card">
                         <h2>Order Confirmation: ${item.confirmationnum}</h2>
                          <h3><strong>Total:</strong> $${item.ordertotal}</h3>
                          <h3><strong>Date:</strong> ${item.orderdate}</h3>
                   </div>
               `;
           });

           document.getElementById("historyorder").innerHTML = html;

       })
       .catch(error => console.log(error));













window.onload = function () {
       loadOrderHistory();

};

